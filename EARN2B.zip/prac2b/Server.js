const express = require('express');
const mongoose = require('mongoose');
const multer = require('multer');
const {GridFSBucket} = require('mongodb');
const cors = require('cors');
const app = express();
app.use(cors());
app.use(express.static('public'));


mongoose.connect('mongodb://127.0.0.1:27017/fileuploads')
    .then(() => console.log('MongoDB connected'))
    .catch(err => console.log(err));
    let bucket;
mongoose.connection.once('open', () => {
    bucket = new GridFSBucket(mongoose.connection.db, {bucketName: 'uploads'});
});
const storage = multer.memoryStorage();
const upload = multer({storage});
app.post('/upload', upload.single('file'), (req, res) => {
    
    const uploadStream = bucket.openUploadStream(req.file.originalname);
    uploadStream.end(req.file.buffer);
    res.send('File uploaded successfully');
});
app.listen(3000, () => {
    console.log('Server started on port 3000');
});