import { Component, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-todo-item',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './todo-item.component.html',
  styleUrls: ['./todo-item.component.css']
})
export class TodoItemComponent {

  @Input() todo: any;

  @Output() delete = new EventEmitter<void>();
  @Output() toggle = new EventEmitter<void>();

  remove() {
    this.delete.emit();
  }

  toggleComplete() {
    this.toggle.emit();
  }
}