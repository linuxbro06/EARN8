import { Component, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TodoItemComponent } from '../todo-item/todo-item.component';

@Component({
  selector: 'app-todo-list',
  standalone: true,
  imports: [CommonModule, TodoItemComponent],
  templateUrl: './todo-list.component.html'
})
export class TodoListComponent {

  @Input() todos: any[] = [];

  @Output() removeTodo = new EventEmitter<number>();
  @Output() toggleTodo = new EventEmitter<number>();

  deleteTodo(index: number) {
    this.removeTodo.emit(index);
  }

  toggle(index: number) {
    this.toggleTodo.emit(index);
  }
}