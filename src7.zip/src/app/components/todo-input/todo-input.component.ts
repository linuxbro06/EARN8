import { Component, EventEmitter, Output } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-todo-input',
  standalone: true,
  imports: [FormsModule, CommonModule],
  templateUrl: './todo-input.component.html'
})
export class TodoInputComponent {

  newTodo: string = '';

  @Output() todoAdded = new EventEmitter<string>();

  addTodo() {
    if (this.newTodo.trim()) {
      this.todoAdded.emit(this.newTodo);
      this.newTodo = '';
    }
  }
}