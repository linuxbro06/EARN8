import { Component } from '@angular/core';
import { TodoInputComponent } from './components/todo-input/todo-input.component';
import { TodoListComponent } from './components/todo-list/todo-list.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [TodoInputComponent, TodoListComponent],
  templateUrl: './app.html',
  styleUrls: ['./app.css']
})
export class App {

  todos: { text: string; completed: boolean }[] = [];

  addTodo(todo: string) {
    this.todos.push({ text: todo, completed: false });
  }

  deleteTodo(index: number) {
    this.todos.splice(index, 1);
  }

  toggleComplete(index: number) {
    this.todos[index].completed = !this.todos[index].completed;
  }
}