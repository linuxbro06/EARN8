import { useState } from "react";

export default function Form() {
    const [id, setId] = useState("");
    const [name, setName] = useState("");
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [confirmPassword, setConfirmPassword] = useState("");
    const [submitted, setSubmitted] = useState(false); // ✅ added

    const handleSubmit = (e) => {
        e.preventDefault();

        if (id === "") {
            alert("ID is required");
            return;
        }

        if (name === "") {
            alert("Name is required");
            return;
        }

        if (email === "" || !email.match(/^[^\s@]+@[^\s@]+\.[^\s@]+$/)) {
            alert("Valid email is required");
            return;
        }

        if (password === "" || password.length < 8) {
            alert("Password must be at least 8 characters long");
            return;
        }

        if (confirmPassword === "" || confirmPassword !== password) {
            alert("Passwords do not match");
            return;
        }

        setSubmitted(true); // ✅ now valid
    };

    return (
        <div>
            <form onSubmit={handleSubmit}>
                <input type="text" placeholder="ID" value={id} onChange={(e) => setId(e.target.value)} /><br/>
                <input type="text" placeholder="Name" value={name} onChange={(e) => setName(e.target.value)} /><br/>
                <input type="email" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} /><br/>
                <input type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} /><br/>
                <input type="password" placeholder="Confirm Password" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} /><br/>
                <button type="submit">Submit</button>
            </form>

            {submitted && (   // ✅ fixed
                <div>
                    <p>ID: {id}</p>
                    <p>Name: {name}</p>
                    <p>Email: {email}</p>
                </div>
            )}
        </div>
    );
}