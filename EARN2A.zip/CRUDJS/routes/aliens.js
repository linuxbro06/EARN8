const express = require('express');
const router = express.Router();
const Alien = require('../models/alien');
// Get all aliens
router.get('/', async (req, res) => {
    try {
        const aliens = await Alien.find();
        res.json(aliens);
    } catch (err) {
        res.send('Error ' + err);
    }
});
// Get a specific alien by ID
router.get('/:id', async (req, res) => {
    try {
        const alien = await Alien.findById(req.params.id);
        res.json(alien);
    } catch (err) {
        res.send('Error ' + err);
    }
});
// Create a new alien
router.post('/', async (req, res) => {  
    const alien = new Alien({
        name: req.body.name,
        tech: req.body.tech,
        sub: req.body.sub
    });     
    try {
        const a1 = await alien.save();
        res.json(a1);
    } catch (err) {
        res.send('Error ' + err);
    }       
});
// Update an existing alien by ID
router.patch('/:id', async (req, res) => {
    try {
        const alien = await Alien.findById(req.params.id);
        alien.sub = req.body.sub;
        const a1 = await alien.save();
        res.json(a1);
    } catch (err) {
        res.send('Error ' + err);
    }
});
// Delete an alien by ID
router.delete('/:id', async (req, res) => { 
    try {
        const alien = await Alien.findById(req.params.id);
        const a1 = await alien.remove();
        res.json(a1);
    } catch (err) {
        res.send('Error ' + err);
    }       
});
module.exports = router;