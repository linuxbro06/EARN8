const express = require('express');
const mongoose = require('mongoose');

const app = express();

const url = 'mongodb://127.0.0.1:27017/AlienDB';

// ✅ FIX: options hata diye
mongoose.connect(url);

const con = mongoose.connection;

con.on('open', () => {
    console.log('Connected to MongoDB...');
});

// Middleware
app.use(express.json());

// Routes
const alienRouter = require('./routes/aliens');
app.use('/aliens', alienRouter);

// Server
app.listen(9000, () => {
    console.log('Server started on port 9000');
});
//npm install express 
// npm install mongoose
//npm install -g nodemon --save-dev
//npm install mongodb 
//npm install swr