import { useEffect, useState } from "react";

const FetchData = () => {
  const [data, setData] = useState([]);

  useEffect(() => {
    fetch(" https://restcountries.com/v3.1/all?fields=name,flags")
      .then((res) => res.json())
      .then((result) => setData(result))
      .catch((err) => console.log(err));
  }, []);

  return (
    <div>
      <h2>Country Flags</h2>
      {data.map((country, index) => (
        <img key={index} src={country.flags.png} width={100} />
      ))}
    </div>
  );
};

export default FetchData;