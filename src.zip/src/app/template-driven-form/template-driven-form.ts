import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { User } from '../models/user';
import { MatchPasswordDirective } from '../directives/match-password';
import { PasswordPatternDirective } from '../directives/password-pattern';
import { ValidateUserNameDirective } from '../directives/validate-user-name';

@Component({
  selector: 'app-template-driven-form',
  templateUrl: './template-driven-form.html',
  styleUrls: ['./template-driven-form.scss'],
  standalone: true,
  imports: [
    FormsModule,
    CommonModule,
    MatchPasswordDirective,
    PasswordPatternDirective,
    ValidateUserNameDirective
  ]
})
export class TemplateDrivenFormComponent {

  userModal = new User();

  constructor() { }

  onSubmit() {
    alert('Form Submitted succesfully!!!\n Check the values in browser console.');
    console.table(this.userModal);
  }
}