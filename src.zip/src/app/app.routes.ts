import { Routes } from '@angular/router';
import { TemplateDrivenFormComponent } from './template-driven-form/template-driven-form';

export const routes: Routes = [
  { path: '', component: TemplateDrivenFormComponent },
  { path: 'template-form', component: TemplateDrivenFormComponent }
];
