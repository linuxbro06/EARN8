import { TestBed } from '@angular/core/testing';

import { Customvalidation } from './customvalidation';

describe('Customvalidation', () => {
  let service: Customvalidation;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(Customvalidation);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
