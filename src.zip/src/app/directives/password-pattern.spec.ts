import { PasswordPattern } from './password-pattern';

describe('PasswordPattern', () => {
  it('should create an instance', () => {
    const directive = new PasswordPattern();
    expect(directive).toBeTruthy();
  });
});
