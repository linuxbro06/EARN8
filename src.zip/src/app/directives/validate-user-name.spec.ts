import { ValidateUserName } from './validate-user-name';

describe('ValidateUserName', () => {
  it('should create an instance', () => {
    const directive = new ValidateUserName();
    expect(directive).toBeTruthy();
  });
});
