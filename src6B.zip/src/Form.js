import { useState } from "react";
import * as yup from "yup";

const validationSchema = yup.object({
    id: yup.string().required("ID is required"),
    name: yup.string().required("Name is required"),
    email: yup.string().email("Valid email is required").required("Valid email is required"),
    password: yup
        .string()
        .required("Password must be at least 8 characters long")
        .min(8, "Password must be at least 8 characters long"),
    confirmPassword: yup
        .string()
        .required("Passwords do not match")
        .oneOf([yup.ref("password")], "Passwords do not match"),
});

export default function Form() {
    const [id, setId] = useState("");
    const [name, setName] = useState("");
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [confirmPassword, setConfirmPassword] = useState("");
    const [submitted, setSubmitted] = useState(false);

    const handleSubmit = async (e) => {
        e.preventDefault();

        try {
            await validationSchema.validate(
                { id, name, email, password, confirmPassword },
                { abortEarly: true }
            );
            setSubmitted(true);
        } catch (error) {
            alert(error.message);
        }
    };

    return (
        <div>
            <form onSubmit={handleSubmit}>
                <input type="text" placeholder="ID" value={id} onChange={(e) => setId(e.target.value)} /><br/>
                <input type="text" placeholder="Name" value={name} onChange={(e) => setName(e.target.value)} /><br/>
                <input type="email" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} /><br/>
                <input type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} /><br/>
                <input type="password" placeholder="Confirm Password" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} /><br/>
                <button type="submit">Submit</button>
            </form>

            {submitted && (
                <div>
                    <p>ID: {id}</p>
                    <p>Name: {name}</p>
                    <p>Email: {email}</p>
                </div>
            )}
        </div>
    );
}
