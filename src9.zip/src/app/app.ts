import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { DataFetcher } from './data-fetcher/data-fetcher';
import { PostManager } from './post-manager/post-manager';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, DataFetcher, PostManager],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('httpclient-fetch-demo');
}
