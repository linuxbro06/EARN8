import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { HttpRequest, HttpEventType } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class PostService {
  private apiUrl = 'https://jsonplaceholder.typicode.com/posts';

  constructor(private http: HttpClient) {}

  getPosts(category?: string): Observable<any> {
    let params = new HttpParams();
    if (category) {
      params = params.set('category', category);
    }

    const headers = new HttpHeaders({
      'Authorization': 'Bearer mock-token',
      'Custom-Header': 'MyApp'
    });

    return this.http.get(this.apiUrl, { headers, params }).pipe(
      catchError(error => {
        console.error('Error fetching posts:', error);
        return throwError(() => new Error('Failed to fetch posts: ' + error.message));
      })
    );
  }

  createPost(post: { title: string; body: string; userId: number }): Observable<any> {
    return this.http.post(this.apiUrl, post).pipe(
      catchError(error => throwError(() => new Error('Failed to create post')))
    );
  }

  updatePost(id: number, post: { title: string; body: string; userId: number }): Observable<any> {
    return this.http.put(`${this.apiUrl}/${id}`, post).pipe(
      catchError(error => throwError(() => new Error('Failed to update post')))
    );
  }

  deletePost(id: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/${id}`).pipe(
      catchError(error => throwError(() => new Error('Failed to delete post')))
    );
  }

  uploadFile(file: File): Observable<any> {
    const formData = new FormData();
    formData.append('file', file);

    const req = new HttpRequest('POST', `${this.apiUrl}/upload`, formData, {
      reportProgress: true
    });

    return this.http.request(req);
  }
}
