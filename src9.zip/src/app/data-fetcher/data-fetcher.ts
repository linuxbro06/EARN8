import { Component, OnInit } from '@angular/core';
import { PostService } from '../post';
import { Observable, of } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-data-fetcher',
  imports: [CommonModule],
  templateUrl: './data-fetcher.html',
  styleUrl: './data-fetcher.css',
})
export class DataFetcher implements OnInit {
  posts$: Observable<any> | null = null;
  error: string | null = null;

  constructor(private postService: PostService) {}

  ngOnInit() {
    this.posts$ = this.postService.getPosts().pipe(
      catchError(err => {
        this.error = err.message;
        return of([]);
      })
    );
  }
}
