import { Component } from '@angular/core';
import { PostService } from '../post';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpEventType } from '@angular/common/http';

@Component({
  selector: 'app-post-manager',
  imports: [CommonModule, FormsModule],
  templateUrl: './post-manager.html',
  styleUrl: './post-manager.css',
})
export class PostManager {
  newPost = { title: '', body: '', userId: 1 };
  updatedPost = { title: 'Updated Title', body: 'Updated Body', userId: 1 };
  postIdToDelete = 1;
  response: any = null;
  uploadProgress: number | null = null;

  constructor(private postService: PostService) {}

  createPost() {
    this.postService.createPost(this.newPost).subscribe({
      next: (res) => this.response = { action: 'Created', data: res },
      error: (err) => this.response = { action: 'Error', data: err }
    });
  }

  updatePost() {
    this.postService.updatePost(1, this.updatedPost).subscribe({
      next: (res) => this.response = { action: 'Updated', data: res },
      error: (err) => this.response = { action: 'Error', data: err }
    });
  }

  deletePost() {
    this.postService.deletePost(this.postIdToDelete).subscribe({
      next: () => this.response = { action: 'Deleted', data: null },
      error: (err) => this.response = { action: 'Error', data: err }
    });
  }

  uploadFile(event: Event) {
    const file = (event.target as HTMLInputElement).files?.[0];
    if (file) {
      this.postService.uploadFile(file).subscribe({
        next: (event: any) => {
          if (event.type === HttpEventType.UploadProgress && event.total) {
            this.uploadProgress = Math.round((event.loaded / event.total) * 100);
          } else if (event.type === HttpEventType.Response) {
            this.response = { action: 'Uploaded', data: event.body };
            this.uploadProgress = null;
          }
        },
        error: (err) => {
          this.response = { action: 'Error', data: err };
          this.uploadProgress = null;
        }
      });
    }
  }
}
